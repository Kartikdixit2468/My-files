import random
import json
import torch
from LanguageProcessing import bag_of_words, tokenize
from NeuralNetwork import NeuralNet
from jarvis_features import non_input_functions, input_functions, greet
from listen import listen
from speak import speak


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

with open('chatbot.json') as file:
    file_data = json.load(file)

File = 'TrainingData.pth'
data = torch.load(File)

# Data from pth file -----------

input_size = data['input_size']
hidden_size = data['hidden_size']
output_size = data['output_size']
model_state = data['model_state']
tags = data['tags']
all_words_list = data["all_words"]

model = NeuralNet(input_size, hidden_size, output_size).to(device)
model.load_state_dict(model_state)
model.eval()

# Jarvis code start

name = 'Jarvis'

def main():
    """ Our jarvis main code (Structure) """
    greet()
    
    while True:
    
        query = listen()

        if 'bye' in query:
            speak("Nice to meet you sir , Exiting")
            exit()
        elif query == "" or query == " ":
            continue
        
        query_ = tokenize(query)
        x = bag_of_words(query_, all_words_list)

        x = x.reshape(1, x.shape[0])
        x = torch.from_numpy(x).to(device)
        output = model(x)
        a, predicted = torch.max(output, dim=1)
        tag = tags[predicted.item()]

        probability = torch.softmax(output, dim=1)
        got_probability = probability[0][predicted.item()]
        
        if got_probability.item() > 0.75:
            for each in file_data['messages']:
                if tag == each['tags']:
                    reply = random.choice(each['responses'])
                    reply = str(reply).lower()

                    if tag == 'greeting' or tag == 'about' or tag == 'about jarvis':
                        speak(reply)

                    if tag == 'bye':
                        speak(reply)
                        exit()

                    if reply == 'time':
                        non_input_functions("time")

                    if reply == 'date':
                        non_input_functions("date")

                    if reply == 'day':
                        non_input_functions("day")

                    if reply == 'internet_speed':
                        non_input_functions("internet_speed")

                    if reply == 'screenshot':
                        non_input_functions("screenshot")
                    
                    if reply == 'translate':
                        non_input_functions("translate")
                    
                    if reply == 'wikipedia':
                        input_functions("wikipedia", query)
                    
                    if reply == 'google_search':
                        input_functions("google_search", query)
                    
                    if reply == 'how_to':
                        input_functions("how_to", query)
                    
                    if reply == 'feedback':
                        input_functions("feedback", query)
                    
                    else:
                        speak(reply)
        else:
            speak("Sorry, Thats Beyond my abilities at the moment")
            speak("If you wan to give feedback say, ' I have feedback'")


if __name__ == '__main__':

    main()
