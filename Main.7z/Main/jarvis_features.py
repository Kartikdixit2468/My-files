# Made by Kartik
from googletrans import Translator
from speak import speak
import datetime
import wikipedia as wk
from pywikihow import search_wikihow
import pyautogui as pg
from pywhatkit import search
from listen import listen
import os
import speedtest



exit_res_list = [
                "Bye",
                "I am Going.",
                "Bye Sir",
                "Good Bye",
                "goodbye",
                "It'll be Nice To Meet You Again",
                "See You Later"
            ]

# Welcome function
def greet():
    """ this function will help jarvis to greet the user """
    msg = "Morning sir, Your AI Assistant Jarvis here."
    speak(msg)

# Non-Input Functions

def time():
    """ This function tells jarvis time. """
    time = datetime.datetime.now().strftime("%H:%M")
    speak(f"It's {time}")

def date():
    " This function tell jarvis date. "
    date = datetime.date.today()
    speak(date)

def check_speed():
    """ This function helps jarvis to calculate the upload and download speed """
    speak("Checking speed...")
    speak("Running speed test...")
    speed = speedtest.Speedtest()
    download_speed = speed.download()
    download_speed = int(download_speed/800000)
    upload_speed = speed.upload()
    upload_speed = int(upload_speed/800000)
    # print(download_speed)
    # print(upload_speed)
    speak(f"Your Download speed is {download_speed} Megabit per second and")
    speak(f"Your upload speed is {upload_speed} Megabit per second.")

def day():
    " This function tell jarvis day. "
    day = datetime.datetime.now().strftime("%A")
    speak(f"Today is {day}")

def non_input_functions(function):
    """ 
    This function returns the non input function  when called in program.

    function: Non-Input function name. (Only string input)

    """
    function = str(function)
    if function.lower() == "time":
        time()
    
    elif function.lower() == "date":
        date()
    
    elif function.lower() == "day":
        day()
    elif function.lower() == "screenshot":
        take_screenshot()
    
    elif function.lower() == "internet_speed":
        check_speed()
      
    elif function == "translate":
        translate_()

# Input Functions

def how_todo_with_steps(s_query):
    """"

    This function returns the searched text about query from wikipedia.
    s_query: Query to search.
    tag: Wikipedia (Needed)

    """
    s_query = str(s_query).lower()
    removable_words = ["jarvis", "hii", "hello", "please", "please tell me", "tell me", "ok tell me", "ok"]
    for i in removable_words:
        s_query = str(s_query).replace(i, "")
    print(s_query)

    result = search_wikihow(s_query)
    result = result[0].summary
    speak(f"According to wikipedia:  {str(result)}")

def wikipedia_(s_query):
    """"

    This function returns the searched text about query from wikipedia.
    s_query: Query to search.
    tag: Wikipedia (Needed)

    """
    s_query = str(s_query).replace("what is ","")
    s_query = str(s_query).replace("Search on wikipedia","")
    s_query = str(s_query).replace("meaning of","")
    s_query = str(s_query).replace("who is","")
    s_query = str(s_query).replace("Jarvis","")
    try:
        result = wk.summary(s_query, sentences=2)
    except:
        search(s_query)
        result = "I found this on the web."
    speak(result)

def google_search(s_query):
    """"

    This function returns the searched text about query from google.
    s_query: Query to search.

    """
    query = str(s_query)
    query = query.replace('jarvis', "")
    query = query.replace('google', "")
    query = query.replace('search', "")
    query = query.replace('the', "")
    search(query)

def translate_(query='None' ,lang='hi' ,TransLang='en'):
    """
     This function translate line hindi to english.
    
    TransLang: language to which you want to translate. (Default: English)
    TransLang: language given in input. (Default: hindi)

    """
    query = str(query)
    if query == 'None':
        speak("Tell Me The Text!")
        query = str(listen())
    if lang == 'hi' and TransLang == "en":
        traslate = Translator()
        result = traslate.translate(src='hi', text=query)
        text = result.text
    speak(f"Translated text is : {text}.")

def take_screenshot():
    """ This function helps jarvis to take the screenshot. """
    speak("Ok Sir , What Should I Name That File ?")
    file_name = listen()
    file_name = file_name + ".png"
    path1 = "F:\\"+ file_name
    ss = pg.screenshot()
    ss.save(path1)
    speak("ScreenShot Saved") 



def input_functions(function, query):
    """ 
    This function returns the input function  when called in program.

    function: Input function name. (Only string input)
    query: input of function.

    """
    function = str(function).lower()
    if function == "wiki":
        wikipedia_(query)
    
    elif function == "google_search":
        google_search(query)
    
        
    elif function == "wikipedia":
        wikipedia_(query)

    
    elif function == "how_to":
        how_todo_with_steps(query)
    
        
    elif function == "feedback":
        feedback()


# other functions
def feedback():
    """ This function helps jarvis to take the feedback """
    speak('Thank You, for helping us let me know your feedback,\n ')
    feedback = str(listen())
    speak('Please tell me your name also.')
    name = str(listen())

    with open("feedback.txt", 'a') as file:
        data = f'FEEDBACK: {feedback}\nDATE: {datetime.date.today()}\nUSER: {name}'
        data = str(data)
        file.write(data)


if __name__ == "__main__":
    pass
