# Made by kartik
import speech_recognition as sr
from speak import speak

def listen():
    """ This function provide our jarvis a ability to listen. """

    recognizer = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening...")
        recognizer.pause_threshold = 1
        query = recognizer.listen(source, 0, 5)

    try:
        print('Recognizing...')
        query = recognizer.recognize_google(query, language="en-in")
        print(f"You said: {query}")

    except:
        speak("Sorry I can't recognize what you say")
        speak("Please Try Again\n")
        qery = " - "
    
    query = str(query)
    return query.lower()


if __name__ == '__main__':
    pass
