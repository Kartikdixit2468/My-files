# try:
#     import numpy
#     print("Import sucessfull")
# except:
#     print("sorry module not found")

import os

os.startfile("C:/Users/Kartik/Desktop/Main/train_model.py")
